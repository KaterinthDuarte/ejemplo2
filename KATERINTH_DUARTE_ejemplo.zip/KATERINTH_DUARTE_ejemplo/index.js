//se crea una constante llamada express y app
const express = require('express');
const app = express();

//arreglo
const estudiantes = [
    {id:1, nombre: 'Juan', edad: 36, sexo: 'M'},
    {id:2, nombre: 'Lola', edad: 24, sexo: 'F'},
    {id:3, nombre: 'Alejandro', edad: 28, sexo: 'M'}
];

//Ruta o endpoint, es la raiz del sitio - callback
app.get('/', (req, res) => {

    //funcion para mostrar algo
    res.send('Bienvenido a Node Js Api');

});

//ruta mostrar lista de estudiantes
app.get('/api/estudiantes', (req, res) => {

     //funcion arreglo estudiantes
    res.send(estudiantes);
});

//Ruta para buscar-recuperar-extraer un estudiante
app.get('/api/estudiantes/:id', (req, res) => {
      
    //Es la variable que almacena un true o false
     const estud = estudiantes.find(c => c.id === parseInt(req.params.id));

     if(!estud)
        res.send("Estudiante no encontrado");
     else
       res.send(estud);
});

//Ruta para agregar un elemento (con post)
app.post('/api/estudiantes', (req, res) => {
    const estud ={
        id: estudiantes.length + 1,
        nombre: req.body.nombre,
        edad: parseInt(req.body.edad),
        sexo: (req.body.sexo),
    }
    estudiantes.push(estud);
    req.send(estud);
});

//Ruta eliminar un registro del arreglo
app.delete('/api/estudiantes/:id',  (req, res) =>{
    const estud = estudiantes.find(c => c.id === parseInt(req.params.id));

    if(!estud)
        return res.status(404).send("Estudiante no encontrado");
    else{
        //indexoff encuentra la posición de un elemento de un arreglo
      const index = estudiantes.indexOf(estud);
      estudiantes.splice(index,1);
      res.send(estud);
    }
});

//crear servidor
const port = process.env.port || 3000;
app.listen(port, () => console.log(`El servidor esta activo en el puerto ${port}`));





